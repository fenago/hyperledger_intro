#  Launches the orderer
#  You may override orderer properties in this file

# Change the logging leve to the desired level
export ORDERER_GENERAL_LOGLEVEL=debug

orderer