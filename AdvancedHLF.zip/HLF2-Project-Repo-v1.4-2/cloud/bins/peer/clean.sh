# Cleans up the Peer VM
rm -rf ledger