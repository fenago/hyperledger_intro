# EDIT THIS To Control the Peer Setup
export ORDERER_ADDRESS=34.234.63.197:7050


export CORE_LOGGING_LEVEL=info

export CORE_PEER_LOCALMSPID=AcmeMSP

# Admin identity used for commands
export CORE_PEER_MSPCONFIGPATH=./msps/admin