# Generate the crypto
cryptogen generate --config=crypto-config.yaml --output=crypto-config