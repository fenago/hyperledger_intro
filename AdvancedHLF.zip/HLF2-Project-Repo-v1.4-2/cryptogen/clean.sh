echo "===== Cleaning the cryptogen ======"
rm -rf ./simple-two-org/crypto-config  2> /dev/null
