#!/bin/bash

# v1.4 requires the config path to be provided
export FABRIC_CFG_PATH=$PWD

orderer