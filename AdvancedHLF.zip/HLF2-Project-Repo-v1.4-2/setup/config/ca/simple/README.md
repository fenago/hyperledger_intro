Multiple configuration files for CA sever and Client
====================================================
config.0    Plain config files with default values
config.1    Added a new bootstrap identity (user)

