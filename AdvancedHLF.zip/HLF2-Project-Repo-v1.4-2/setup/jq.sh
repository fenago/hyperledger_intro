# Installs the JQ Utility

sudo apt-get install -y jq
